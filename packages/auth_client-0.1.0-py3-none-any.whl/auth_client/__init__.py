"Auth client for Python."

from auth_client.client import (
    Auth,
    AuthAccessTokenACRTooLow,
    AuthAccessTokenExpired,
    AuthAccessTokenInfo,
    AuthAccessTokenInvalid,
    AuthAccessTokenMissingPermission,
    AuthAccessTokenMissingScope,
    AuthACR,
    AuthAsync,
    AuthError,
    AuthIdTokenInvalid,
    AuthRequestError,
    AuthTokenResponse,
    AuthUserInfo,
)

__version__ = "0.20.0"

__all__ = [
    "Auth",
    "AuthACR",
    "AuthAsync",
    "AuthTokenResponse",
    "AuthAccessTokenInfo",
    "AuthUserInfo",
    "AuthError",
    "AuthAccessTokenACRTooLow",
    "AuthAccessTokenExpired",
    "AuthAccessTokenMissingPermission",
    "AuthAccessTokenMissingScope",
    "AuthAccessTokenInvalid",
    "AuthIdTokenInvalid",
    "AuthRequestError",
    "crypto",
    "pkce",
    "integrations",
]

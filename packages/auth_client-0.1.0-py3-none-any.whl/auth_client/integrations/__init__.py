"""Modules containing helpers and shortcuts for popular frameworks."""
